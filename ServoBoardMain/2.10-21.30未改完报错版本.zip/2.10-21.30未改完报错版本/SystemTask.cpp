#include "SystemTask.h"

// =============== 全局变量定义 ===============
// 【注意】由于原 ino 中使用了全局变量，此处需显式定义
volatile uint8_t g_calibrationUIStatus = 0;

// 舵机管理器实例（即使未使用，若其他地方仍有引用，可保留；否则可删除）
// 若完全移除 ServoCtrlTask，且无其他地方使用，请注释掉以下三行
// ServoManager servoManager0(BUS0_SERVO_NUM);
// ServoManager servoManager1(BUS1_SERVO_NUM);
// ServoManager* servoManagers[NUM_SERVO_BUSES] = { &servoManager0, &servoManager1 };

// 共享数据实例
volatile uint8_t g_calibrationUIStatus = 0;
TaskSharedData_t sharedData;

// 任务句柄
TaskHandle_t taskUpperCommHandle = NULL;
TaskHandle_t taskCanCommHandle   = NULL;
TaskHandle_t taskSolverHandle    = NULL; // [新增] 解算任务句柄

// [新增] 核心控制实例
AngleSolver angleSolver;
ServoBusManager servoBus0; // 对应 Bus 0
ServoBusManager servoBus1; // 对应 Bus 1
ServoBusManager servoBus2; // [新增]
ServoBusManager servoBus3; // [新增]

// [新增] 数据缓冲区 (21个关节)
float global_Targets[ENCODER_TOTAL_NUM];      // 目标角度
float global_CanAngles[ENCODER_TOTAL_NUM];    // 磁编实际角度
float global_ServoAngles[ENCODER_TOTAL_NUM];  // 舵机反馈角度
int16_t global_OutPulses[ENCODER_TOTAL_NUM];  // 输出脉冲控制量

// [新增] 关节映射表: 将 0-20 索引映射到 (BusIndex, ServoID)
// 请根据实际硬件连接修改此处 ID
struct JointMapItem {
    uint8_t busIndex;
    uint8_t servoID;
};

// [修改] 21个关节在 4 路总线上的映射示例
// 请根据实际硬件连线修改 (Bus 0-3, ID 1-N)
JointMapItem jointMap[ENCODER_TOTAL_NUM] = {
    // Bus 0 (5个)
    {0, 1}, {0, 2}, {0, 3}, {0, 4}, {0, 5},
    // Bus 1 (5个)
    {1, 1}, {1, 2}, {1, 3}, {1, 4}, {1, 5},
    // Bus 2 (5个)
    {2, 1}, {2, 2}, {2, 3}, {2, 4}, {2, 5},
    // Bus 3 (6个)
    {3, 1}, {3, 2}, {3, 3}, {3, 4}, {3, 5}, {3, 6}
};

// 辅助函数: 角度归一化或者是单位转换
// 假设磁编 0-16383 对应 0-360度
float convertCanToDeg(uint16_t rawVal) {
    return (rawVal * 360.0f) / 16384.0f;
}


// =============== 系统初始化函数 ===============
void System_Init() {
    // 初始化串口
    Serial.begin(921600);
    while (!Serial) {
        delay(10);
    }

    // servoBus0.begin(0, RX1_PIN, TX1_PIN); 
    // servoBus1.begin(1, RX2_PIN, TX2_PIN); 
    // 暂用默认演示：
    servoBus0.begin(BUS0_RX_PIN, BUS0_TX_PIN);
    servoBus1.begin(BUS1_RX_PIN, BUS1_TX_PIN);
    servoBus2.begin(BUS2_RX_PIN, BUS2_TX_PIN);
    servoBus3.begin(BUS3_RX_PIN, BUS3_TX_PIN);
    
    delay(1000);

    // 创建命令队列 (用于上位机通信)
    sharedData.cmdQueue = xQueueCreate(5, sizeof(ServoCommand_t));
    if (sharedData.cmdQueue == NULL) {
        Serial.println("[ERR] cmdQueue create failed!");
        while (1);
    }

    // 创建状态队列 (已废弃，但为兼容旧接口保留)
    sharedData.statusQueue = xQueueCreate(3, sizeof(ServoStatus_t));
    if (sharedData.statusQueue == NULL) {
        Serial.println("[ERR] statusQueue create failed!");
        while (1);
    }

    // 【新增】创建 CAN 相关队列
    sharedData.canRxQueue = xQueueCreate(1, sizeof(RemoteSensorData_t)); // 最新数据
    sharedData.canTxQueue = xQueueCreate(5, sizeof(RemoteCommand_t));   // 指令缓冲
    if (sharedData.canRxQueue == NULL || sharedData.canTxQueue == NULL) {
        Serial.println("[ERR] CAN queues create failed!");
        while (1);
    }

        // 3. [新增] AngleSolver 初始化
    // 3.1 机械零位与方向 (示例全0，请填入实际值)
    int16_t zeros[ENCODER_TOTAL_NUM] = {0}; 
    float ratios[ENCODER_TOTAL_NUM];
    int8_t dirs[ENCODER_TOTAL_NUM];
    
    for(int i=0; i<ENCODER_TOTAL_NUM; i++) {
        zeros[i] = 2048; // 默认中位
        ratios[i] = 1.0f;
        dirs[i] = 1;
        
        // 初始化目标角度为当前位置或0，防止上电飞车
        global_Targets[i] = 0.0f; 
    }
    angleSolver.init(zeros, ratios, dirs);

    // 3.2 [关键] 设置PID参数 (集成您之前提供的参数)
    // [0]=外环(位置), [1]=内环(速度/舵机)
    float pidConfigs[2][PID_PARAMETER_NUM] = {
        {20.0f, 0.0f, 0.0f, 0.0f, 0.0f, 3000.0f}, // Loop 1: Mag -> Correction
        { 5.0f, 0.0f, 0.0f, 0.0f, 0.0f, 30719.0f}  // Loop 2: Correction+Cur -> Servo
    };
    angleSolver.setPIDParams(pidConfigs);

    
    // 创建任务
    xTaskCreate(
        taskUpperComm,
        "UpperComm",
        UPPER_COMM_TASK_STACK_SIZE,
        &sharedData,
        TASK_UPPER_COMM_PRIORITY,
        &taskUpperCommHandle
    );

    // 【关键】已移除 ServoCtrlTask 的创建
    // xTaskCreate(taskServoCtrl, "ServoCtrl", ..., &taskServoCtrlHandle);

    xTaskCreate(
        taskCanComm,
        "CanComm",
        CAN_COMM_TASK_STACK_SIZE,
        &sharedData,
        TASK_CAN_COMM_PRIORITY,
        &taskCanCommHandle
    );

     // [新增] 创建独立的角度解算任务
    xTaskCreate(taskSolver, "Solver", SOLVER_TASK_STACK_SIZE, NULL, TASK_SOLVER_PRIORITY, &taskSolverHandle);

    Serial.println("✅ FreeRTOS tasks created successfully.");
    Serial.println("🚀 System ready. Commands: s(停止), r(恢复)");
}

// =============== 主循环函数 ===============
void System_Loop() {
    static uint32_t lastPrintTime = 0;

    // 每 200ms 打印一次监控信息（非阻塞）
    if (millis() - lastPrintTime > 200) {
        lastPrintTime = millis();
        // 可选：调用 printCanMonitor(); 但建议移到 CanCommTask 内部或独立调试任务
    }

    // 必须延时，防止看门狗复位
    vTaskDelay(pdMS_TO_TICKS(10));
}

// ==========================================
// [XSimple] CAN 数据监控函数 (P4端) —— 建议移至此处或单独文件
// ==========================================
void printCanMonitor() {
    RemoteSensorData_t sensorData;
    if (xQueuePeek(sharedData.canRxQueue, &sensorData, 0) == pdFALSE) {
        Serial.println("[WARN] No CAN data received yet");
        return;
    }

    Serial.println("\n========== [ CAN Sensor Monitor (S3 -> P4) ] ==========");
    Serial.printf("Total Encoders: %d | Update Time: %lu ms\n", ENCODER_TOTAL_NUM, millis());

    for (int i = 0; i < ENCODER_TOTAL_NUM; i++) {
        uint16_t val = sensorData.encoderValues[i];
        bool isError = (val == 0 || val == 0xFFFF || val == 16383);
        Serial.printf("[%02d] 0x%04X (%6.1f°) %s  ", 
                     i, val, (val * 360.0f) / 16384.0f, isError ? "⚠️" : "✅");

        if ((i + 1) % 4 == 0) Serial.println();
    }

    if (ENCODER_total_NUM % 4 != 0) Serial.println();
    Serial.println("======================================================");
}

void taskSolver(void *pvParameters) {
    TickType_t xLastWakeTime;
    const TickType_t xFrequency = pdMS_TO_TICKS(CONTROL_PERIOD_MS); // 20ms
    
    // 初始化唤醒时间
    xLastWakeTime = xTaskGetTickCount();

    for (;;) {
        // [关键] 绝对延时，确保周期稳定
        vTaskDelayUntil(&xLastWakeTime, xFrequency);

        // 1. --- 获取最新指令 ---
        ServoCommand_t cmd;
        while (xQueueReceive(sharedData.cmdQueue, &cmd, 0) == pdTRUE) {
            if (cmd.servoID < ENCODER_TOTAL_NUM) {
                // 解析指令逻辑...
            }
        }

        // 2. --- 获取传感器反馈 (CAN Mag) ---
        RemoteSensorData_t sensorData;
        if (xQueuePeek(sharedData.canRxQueue, &sensorData, 0) == pdTRUE) {
            for(int i=0; i<ENCODER_TOTAL_NUM; i++) {
                global_CanAngles[i] = convertCanToDeg(sensorData.encoderValues[i]);
            }
        }

        // 3. --- 获取舵机反馈 (多圈解算) ---
        // [修改] 遍历所有 21 个关节，根据映射表从 4 条总线获取
        for(int i=0; i<ENCODER_TOTAL_NUM; i++) {
            uint8_t bus = jointMap[i].busIndex;
            uint8_t id  = jointMap[i].servoID;
            
            // [新增] 选择对应的总线对象 (0-3)
            ServoBusManager* pBus = NULL;
            switch(bus) {
                case 0: pBus = &servoBus0; break;
                case 1: pBus = &servoBus1; break;
                case 2: pBus = &servoBus2; break; // [新增]
                case 3: pBus = &servoBus3; break; // [新增]
                default: continue;
            }
            
            if(pBus) {
                int32_t absPulse = pBus->updateAndGetAbsolutePulse(bus, id);
                global_ServoAngles[i] = (absPulse - 2048) / 11.3777f; 
            }
        }

        // 4. --- 核心解算 ---
        angleSolver.compute(global_Targets, global_CanAngles, global_ServoAngles, global_OutPulses);

        // 5. --- 执行输出 ---
        for(int i=0; i<ENCODER_TOTAL_NUM; i++) {
            uint8_t bus = jointMap[i].busIndex;
            uint8_t id  = jointMap[i].servoID;
            
            ServoBusManager* pBus = NULL;
            switch(bus) {
                case 0: pBus = &servoBus0; break;
                case 1: pBus = &servoBus1; break;
                case 2: pBus = &servoBus2; break; // [新增]
                case 3: pBus = &servoBus3; break; // [新增]
            }

            if(pBus) {
                pBus->setServoTarget(bus, id, global_OutPulses[i], 0, 0);
            }
        }
        
        // [修改] 同步 4 条总线
        servoBus0.syncWriteAll();
        servoBus1.syncWriteAll();
        servoBus2.syncWriteAll(); // [新增]
        servoBus3.syncWriteAll(); // [新增]
    }
}