#ifndef SYSTEM_TASK_H
#define SYSTEM_TASK_H

// 核心依赖
#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>

// 应用层头文件
#include "TaskSharedData.h"
#include "UpperCommTask.h"
#include "CanCommTask.h" // 注意：不再包含 ServoCtrlTask.h
#include "AngleSolver.h"      // [新增] 引入解算器
#include "ServoBusManager.h"  // [新增] 引入舵机总线管理

// 关节数量定义
#define ENCODER_TOTAL_NUM 21
#define CONTROL_PERIOD_MS 20  // [新增] 控制周期 20ms (50Hz)
// 全局状态标志位（跨任务共享）


// [新增] 定义解算任务参数
#define SOLVER_TASK_STACK_SIZE 4096
#define TASK_SOLVER_PRIORITY 2  // 优先级建议: Can(高) > Solver(中) > Upper(低)

extern volatile uint8_t g_calibrationUIStatus;

// 系统初始化函数（替代 setup() 中的逻辑）
void System_Init();

// 主循环函数（替代 loop()）
void System_Loop();

// [新增] 独立解算任务函数声明
void taskSolver(void *pvParameters);


#endif // SYSTEM_TASK_H 