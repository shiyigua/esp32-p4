// ServoBusManager.cpp
#include "ServoBusManager.h"


// [新增] 定义半圈阈值，用于判断是否过零
#define HALF_TURN_THRESHOLD 2048
#define FULL_TURN_STEPS     4096


ServoBusManager::ServoBusManager() {
    serials[0] = &Serial1; // 根据P4定义映射
    serials[1] = &Serial2;
    serials[2] = &Serial3;
    serials[3] = &Serial4;
    
    for(int i=0; i<NUM_BUSES; i++) _counts[i] = 0;

       // [新增] 初始化状态数组
    for(int b=0; b<NUM_BUSES; b++) {
        for(int s=0; s<32; s++) {
            _servoStates[b][s].isInitialized = false;
            _servoStates[b][s].totalTurns = 0;
            _servoStates[b][s].absolutePulse = 0;
            _servoStates[b][s].lastRawPos = -1;
        }
    }
}

void ServoBusManager::begin() {
    serials[0]->begin(SERVO_BAUDRATE, SERIAL_8N1, BUS0_RX_PIN, BUS0_TX_PIN);
    serials[1]->begin(SERVO_BAUDRATE, SERIAL_8N1, BUS1_RX_PIN, BUS1_TX_PIN);
    serials[2]->begin(SERVO_BAUDRATE, SERIAL_8N1, BUS2_RX_PIN, BUS2_TX_PIN);
    serials[3]->begin(SERVO_BAUDRATE, SERIAL_8N1, BUS3_RX_PIN, BUS3_TX_PIN);

    for (int i = 0; i < NUM_BUSES; i++) {
        sms[i].pSerial = serials[i];
    }
}

void ServoBusManager::setServoTarget(uint8_t busIndex, uint8_t servoID, int16_t position, uint16_t speed, uint8_t acc) {
    if (busIndex >= NUM_BUSES) return;
    
    uint8_t idx = _counts[busIndex];
    if (idx >= 10) return; // 防止溢出

    _ids[busIndex][idx] = servoID;
    _pos[busIndex][idx] = position;
    _spd[busIndex][idx] = speed;
    _acc[busIndex][idx] = acc;
    _counts[busIndex]++;
}

void ServoBusManager::syncWriteAll() {
    for (int i = 0; i < NUM_BUSES; i++) {
        if (_counts[i] > 0) {
            // 调用 SMS_STS 库的同步写
            sms[i].SyncWritePosEx(_ids[i], _counts[i], _pos[i], _spd[i], _acc[i]);
            // 清空计数器，准备下一帧
            _counts[i] = 0;
        }
    }
}


// [新增] 核心多圈解算逻辑
int32_t ServoBusManager::updateAndGetAbsolutePulse(uint8_t busIndex, uint8_t servoID) {
    if (busIndex >= NUM_BUSES || servoID >= 32) return 0;

    // 1. 读取当前原始位置 (0-4095)
    int rawPos = sms[busIndex].ReadPos(servoID);
    
    if (rawPos == -1) {
        return _servoStates[busIndex][servoID].absolutePulse; // 读取失败返回旧值
    }

    ServoState &state = _servoStates[busIndex][servoID];

    // 2. 如果是首次运行，直接对齐
    if (!state.isInitialized) {
        state.lastRawPos = rawPos;
        state.absolutePulse = rawPos; // 初始时刻默认为0圈，位置即为当前值
        // 如果电机上电时不在0位，这里可能需要Offset逻辑，暂按原始值处理
        state.isInitialized = true;
        return state.absolutePulse;
    }

    // 3. 计算差值 (当前 - 上次)
    int diff = rawPos - state.lastRawPos;

    // 4. 过零检测逻辑
    // 如果差值突变很大 (例如从 4090 变到 10，差值 -4080)，说明正向过零
    if (diff < -HALF_TURN_THRESHOLD) {
        state.totalTurns++;  // 正向增加一圈
        diff += FULL_TURN_STEPS; // 修正差值用于平滑计算（可选）
    } 
    // 如果差值突变很大 (例如从 10 变到 4090，差值 +4080)，说明反向过零
    else if (diff > HALF_TURN_THRESHOLD) {
        state.totalTurns--;  // 反向减少一圈
        diff -= FULL_TURN_STEPS;
    }

    // 5. 更新状态
    state.lastRawPos = rawPos;
    
    // 计算绝对位置 = 圈数 * 4096 + 当前原始位置
    state.absolutePulse = (state.totalTurns * FULL_TURN_STEPS) + rawPos;

    return state.absolutePulse;
}

// [新增] 获取缓存值
int32_t ServoBusManager::getStoredAbsolutePulse(uint8_t busIndex, uint8_t servoID) {
    if (busIndex >= NUM_BUSES || servoID >= 32) return 0;
    return _servoStates[busIndex][servoID].absolutePulse;
}