#ifndef SERVO_BUS_MANAGER_H
#define SERVO_BUS_MANAGER_H

#include "SMS_STS.h"
// #include "AppConfig.h" // 假设包含 NUM_BUSES 等定义
#include <Arduino.h>
#include "TaskSharedData.h"

// // [新增] 舵机状态结构体，用于多圈计数
// struct ServoState {
//     int16_t  lastRawPos;     // 上一次读取的原始位置 (0-4095)
//     int32_t  totalTurns;     // 累计圈数
//     int32_t  absolutePulse;  // 累计后的绝对脉冲值
//     bool     isInitialized;  // 是否已初始化
// };

class ServoBusManager {
public:
    ServoBusManager();

    // [修改] begin函数增加引脚参数，赋默认值
    // 如果不传参，则需要在 .cpp 中根据 busIndex 使用宏定义
    void begin(int rxPin , int txPin );


    // ... 原有的 setServoTarget 等函数 ...
    void setServoTarget(uint8_t busIndex, uint8_t servoID, int16_t position, uint16_t speed, uint8_t acc);
    void syncWriteAll();

    /**
     * [新增] 读取并更新指定舵机的多圈绝对位置
     * @param busIndex 总线索引
     * @param servoID 舵机ID
     * @return 累加后的绝对脉冲值 (例如 > 4096 或 < 0)
     */
    int32_t updateAndGetAbsolutePulse(uint8_t busIndex, uint8_t servoID);

    // [新增] 获取某个舵机的当前绝对位置（不读取硬件，仅返回缓存）
    int32_t getStoredAbsolutePulse(uint8_t busIndex, uint8_t servoID);

private:
    SMS_STS sms[NUM_BUSES];
    HardwareSerial* serials[NUM_BUSES];
    
    // 发送缓冲区
    uint8_t  _ids[NUM_BUSES][10]; 
    int16_t  _pos[NUM_BUSES][10];
    uint16_t _spd[NUM_BUSES][10];
    uint8_t  _acc[NUM_BUSES][10];
    uint8_t  _counts[NUM_BUSES];

    // [新增] 状态存储数组 [总线][舵机ID(假设最大32)]
    // 注意：如果ID不连续，建议使用 Hash map 或 只是简单的大数组
    ServoState _servoStates[NUM_BUSES][32]; 
};

#endif

// // ServoBusManager.h
// #ifndef SERVO_BUS_MANAGER_H
// #define SERVO_BUS_MANAGER_H

// #include "SMS_STS.h" // 引用您上传的库
// #include "AppConfig.h"
// #include <Arduino.h>

// class ServoBusManager {
// public:
//     ServoBusManager();
//     void begin(); // 初始化串口

//     /**
//      * @brief 发送单个舵机指令（会放入内部缓冲，调用 syncWriteAll 统一发送）
//      */
//     void setServoTarget(uint8_t busIndex, uint8_t servoID, int16_t position, uint16_t speed, uint8_t acc);

//     /**
//      * @brief 立即执行所有总线的同步写操作
//      */
//     void syncWriteAll();

// private:
//     SMS_STS sms[NUM_BUSES];
//     HardwareSerial* serials[NUM_BUSES];
    
//     // 简单的本地缓存，用于组包
//     // [BusIndex][BufferIndex]
//     uint8_t  _ids[NUM_BUSES][10]; 
//     int16_t  _pos[NUM_BUSES][10];
//     uint16_t _spd[NUM_BUSES][10];
//     uint8_t  _acc[NUM_BUSES][10];
//     uint8_t  _counts[NUM_BUSES];
// };

// #endif