#ifndef TASK_SHARED_DATA_H
#define TASK_SHARED_DATA_H

#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include "ServoManager.h"
#include <stdint.h>

// // 舵机总线数量及引脚
// #define NUM_SERVO_BUSES 4
// #define UART1_rxPin 22
// #define UART1_txPin 23
// #define UART2_rxPin 20
// #define UART2_txPin 21
// #define UART3_txPin 26
// #define UART3_rxPin 37
// #define UART4_txPin 33
// #define UART4_rxPin 32

// static const uint8_t BUS0_IDS[] = {0, 2, 5, 7, 9, 11, 13, 14, 17, 19};
// static const uint8_t BUS0_SERVO_NUM = sizeof(BUS0_IDS) / sizeof(BUS0_IDS[0]);
// static const uint8_t BUS1_IDS[] = {1, 3, 4, 6, 8, 10, 12, 15, 18}; // TODO: remove 16
// static const uint8_t BUS1_SERVO_NUM = sizeof(BUS1_IDS) / sizeof(BUS1_IDS[0]);

// // 舵机初始化位置结构体
// struct InitConfig {
//     uint8_t busIndex;   // 总线索引
//     uint8_t servoID;    // 舵机ID
//     float   percent;    // 目标位置百分比 (0.0 = 2048, 1.0 = 极限位置)
// };

// // 舵机初始化顺序和配置
// static const InitConfig SERVO_INIT_SEQUENCE[] = {
//     // {总线号, 舵机ID, 百分比位置}
//     {0, 0, 1.0}, 
//     {1, 1, 0.0}, 
//     {0, 2, 0.0}, 
//     {1, 3, 0.0}, 
//     {1, 4, 1.0}, 
//     {0, 5, 0.0}, 
//     {1, 6, 0.0}, 
//     {0, 7, 0.0}, 
//     {1, 8, 1.0}, 
//     {0, 9, 0.0}, 
//     {1, 10, 0.0}, 
//     {0, 11, 0.0}, 
//     {1, 12, 1.0}, 
//     {0, 13, 0.0}, 
//     {0, 14, 0.0}, 
//     {1, 15, 0.0}, 
//     // TODO: {1, 16, 1.0}, 
//     {0, 17, 0.0}, 
//     {1, 18, 0.0}, 
//     {0, 19, 0.0} 
// };


// ================= 硬件定义 (ESP32-P4) =================
#define BUS0_RX_PIN 22
#define BUS0_TX_PIN 23
#define BUS1_RX_PIN 20
#define BUS1_TX_PIN 21
#define BUS2_RX_PIN 26
#define BUS2_TX_PIN 37
#define BUS3_RX_PIN 33
#define BUS3_TX_PIN 32

#define SERVO_BAUDRATE 1000000

// ================= 系统配置 =================
#define NUM_BUSES 4
#define TOTAL_SERVOS 21
#define CTRL_FREQ_HZ 50 // 控制频率 50Hz (20ms)


// ================= 数据结构 =================

// 关节数据包 (用于解算)
struct JointData {
    uint8_t jointId;      // 逻辑关节ID (用于区分不同关节)
    float   targetAngle;  // 外部输入的目标角度 (度)
    float   actualAngle;  // CAN回传的真实角度 (度)
};

// 舵机指令包 (用于驱动)
struct ServoCommand {
    uint8_t busIndex;     // 总线索引 0-3
    uint8_t servoId;      // 物理舵机ID
    int16_t position;     // 目标位置脉冲 (0-4095)
    uint16_t speed;       // 运行速度
    uint8_t  acc;         // 加速度
};


// --- 【新增】CAN / TWAI 配置 ---
#define TWAI_TX_PIN 47  // 请根据实际 P4 硬件连接修改
#define TWAI_RX_PIN 48  // 请根据实际 P4 硬件连接修改


// 任务优先级定义
#define TASK_UPPER_COMM_PRIORITY 1
#define TASK_SERVO_CTRL_PRIORITY 2
#define TASK_CAN_COMM_PRIORITY   3  // 【新增】CAN通信优先级



typedef struct {
    uint16_t encoderValues[21];             // 编码器角度值 (0~16383)
    uint8_t  errorFlags[21];                // 【新增】单个编码器错误标志 (1=错误, 0=正常)
    uint32_t errorBitmap;                   // 【新增】全局错误位图 (来自 CAN 0x1F0)
    uint32_t timestamp;                     // 数据时间戳
    bool     isValid;                       // 【新增】数据有效性标志
} RemoteSensorData_t;

// --- 【新增】发送给 ESP32-S3 的指令结构 ---
typedef struct {
    uint8_t cmdID;
    uint8_t payload[8];
    uint8_t len;
} RemoteCommand_t;


// 命令结构体
typedef struct {
    char command;
    uint32_t timestamp;
    uint8_t mode;      // 0=位置, 1=停止 等
    uint8_t servoID;   // 关节ID
    float   position;  // 目标角度
} ServoCommand_t;

// 状态结构体
typedef struct {
    ServoState* states;
    uint32_t timestamp;
    bool valid;
    uint8_t totalServoNum;
} ServoStatus_t;

// 任务间共享的数据结构
typedef struct {
    QueueHandle_t cmdQueue;
    QueueHandle_t statusQueue;

        // 【新增】CAN 通信队列
    QueueHandle_t canTxQueue;    // 存放要发给 S3 的指令
    QueueHandle_t canRxQueue;    // 存放从 S3 收到的解包数据
    
    ServoManager* servoManagers[NUM_BUSES];
    uint8_t totalServoNum;
} TaskSharedData_t;

#endif